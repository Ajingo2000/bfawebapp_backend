from django.urls import path
from bfaWebApp.views import *
from bfaWebApp import views 

urlpatterns = [
    
  ]



