from django.urls import path
from bfaNewsletter import views

urlpatterns = [
    
]